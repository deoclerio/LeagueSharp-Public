﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LeagueSharp;
using LeagueSharp.Common;
using System.Threading.Tasks;

namespace SigmaSeries.Plugins
{
    public class Cassiopeia : PluginBase
    {
        public Cassiopeia()
            : base(new Version(0, 1, 1))
        {
            Q = new Spell(SpellSlot.Q, 925);
            W = new Spell(SpellSlot.W, 925);
            E = new Spell(SpellSlot.E, 700);
            R = new Spell(SpellSlot.R, 875);

            Q.SetSkillshot(0.5f, 130, float.MaxValue, false, SkillshotType.SkillshotCircle);
            W.SetSkillshot(0.5f, 212, 2500, false, SkillshotType.SkillshotCircle);
            R.SetSkillshot(0.5f, 210, float.MaxValue, false, SkillshotType.SkillshotCone);
        }

        public override void ComboMenu(Menu config)
        {
            config.AddItem(new MenuItem("packetCast", "Packet Cast").SetValue(true));
            config.AddItem(new MenuItem("UseQCombo", "Use Q").SetValue(true));
            config.AddItem(new MenuItem("UseWCombo", "Use W").SetValue(true));
            config.SubMenu("Combo").AddItem(new MenuItem("UseECombo", "Use E").SetValue(true));
        }

        public override void OnUpdate(EventArgs args)
        {
            var pCast = Config.Item("packetCast").GetValue<bool>();
            if (ComboActive)
            {
                var useQCombo = Config.Item("UseQCombo").GetValue<bool>();
                var useWCombo = Config.Item("UseWCombo").GetValue<bool>();
                var useECombo = Config.Item("UseECombo").GetValue<bool>();
                var eTarget = SimpleTs.GetTarget(1000f, SimpleTs.DamageType.Magical);
                if (eTarget != null)
                {
                    if (Player.Distance(eTarget) < E.Range && E.IsReady() && useECombo)
                    {
                        if (eTarget.HasBuffOfType(BuffType.Poison) || E.GetDamage(eTarget) > eTarget.Health)
                        {
                            E.CastOnUnit(eTarget, pCast);
                            return;
                        }
                    }
                    if (Player.Distance(eTarget) < Q.Range && Q.IsReady() && useQCombo)
                    {
                        Q.Cast(eTarget, pCast);
                        return;
                    }
                    if (Player.Distance(eTarget) < W.Range && W.IsReady() && useWCombo)
                    {
                        W.Cast(eTarget, pCast);
                        return;
                    }
                }
            }
        }
    }
}
