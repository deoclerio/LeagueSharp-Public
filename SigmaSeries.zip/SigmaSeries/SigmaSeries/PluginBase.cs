﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using LeagueSharp;
using LeagueSharp.Common;

namespace SigmaSeries
{
    public abstract class PluginBase
    {
        public string ChampName { get; set; }
        public Orbwalking.Orbwalker Orbwalker { get; set; }
        public Version Version {get; set;}
        public bool ComboActive { get { return Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.Combo; } }
        public bool HarassActive { get { return Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.Mixed; } }
        public bool WaveClearActive { get { return Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.LaneClear; } }
        public bool JungleActive { get { return Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.LaneClear; } }
        public bool FreezeActive { get { return Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.LastHit; } }
        public Obj_AI_Hero Player { get { return ObjectManager.Player; } }
        public Spell Q { get; set; }
        public Spell W { get; set; }
        public Spell E { get; set; }
        public Spell R { get; set; }

        public Menu Config { get; set; }
        public Menu ComboConfig { get; set; }
        public Menu HarassConfig { get; set; }
        public Menu DrawConfig { get; set; }
        public Menu FarmConfig { get; set; }
        public Menu BonusConfig { get; set; }

        private List<Spell> SpellList = new List<Spell>();

        protected PluginBase(Version version)
        {
            ChampName = Player.ChampionName;
            Version = version;

            Game.PrintChat("Sigma" + ChampName + " Loaded. Version: " + Version.ToString() + " - By Fluxy");
        }

        private void eventsLoad()
        {
            Game.OnGameUpdate += OnUpdate;
            Drawing.OnDraw += OnDraw;
            Orbwalking.BeforeAttack += BeforeAttack;
            Orbwalking.AfterAttack += AfterAttack;
            AntiGapcloser.OnEnemyGapcloser += OnEnemyGapcloser;
            Interrupter.OnPossibleToInterrupt += OnPossibleToInterrupt;
        }

        private void extraEvents()
        {
            Drawing.OnDraw += args =>
            {
                foreach (var spell in SpellList)
                {
                    var getMenu = Config.Item(spell.Slot + "Range" + ChampName).GetValue<Circle>();
                    if (getMenu.Active && spell.IsReady())
                    {
                        Drawing.DrawCircle(Player.Position, spell.Range, getMenu.Color);
                    }
                }
            };
        }

        private void createConfigs()
        {
            Config = new Menu("Sigma" + Player.ChampionName, "Sigma" + Player.ChampionName);

            Config.AddSubMenu(new Menu("Orbwalking", "Orbwalking"));
            ComboConfig = Config.AddSubMenu(new Menu("Combo", "Combo"));
            HarassConfig = Config.AddSubMenu(new Menu("Harass", "Harass"));
            FarmConfig = Config.AddSubMenu(new Menu("Farm", "Farm"));
            BonusConfig = Config.AddSubMenu(new Menu("Extra", "Extra"));

            DrawConfig = Config.AddSubMenu(new Menu("Draw", "Draw"));
            DrawConfig.AddItem(new MenuItem("QRange" + ChampName, "Q Range").SetValue(new Circle(false, System.Drawing.Color.Green)));
            DrawConfig.AddItem(new MenuItem("WRange" + ChampName, "W Range").SetValue(new Circle(false, System.Drawing.Color.Green)));
            DrawConfig.AddItem(new MenuItem("ERange" + ChampName, "E Range").SetValue(new Circle(false, System.Drawing.Color.Green)));
            DrawConfig.AddItem(new MenuItem("RRange" + ChampName, "R Range").SetValue(new Circle(false, System.Drawing.Color.Green)));

            ComboMenu(ComboConfig);
            HarassMenu(HarassConfig);
            FarmMenu(FarmConfig);
            BonusMenu(BonusConfig);
            DrawingMenu(DrawConfig);
        }

        public virtual void ComboMenu(Menu config)
        {
        }
        public virtual void HarassMenu(Menu config)
        {
        }
        public virtual void FarmMenu(Menu config)
        {
        }
        public virtual void BonusMenu(Menu config)
        {
        }
        public virtual void DrawingMenu(Menu config)
        {
        }

        public virtual void OnDraw(EventArgs args)
        {
        }

        public virtual void OnUpdate(EventArgs args)
        {
        }

        public virtual void BeforeAttack(Orbwalking.BeforeAttackEventArgs args)
        {
        }

        public virtual void AfterAttack(Obj_AI_Base unit, Obj_AI_Base target)
        {
        }

        public virtual void OnEnemyGapcloser(ActiveGapcloser gapcloser)
        {
        }

        public virtual void OnPossibleToInterrupt(Obj_AI_Base unit, InterruptableSpell spell)
        {
        }
    }
}
